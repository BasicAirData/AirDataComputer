## Asgard
Android Application to interface with the ADC
