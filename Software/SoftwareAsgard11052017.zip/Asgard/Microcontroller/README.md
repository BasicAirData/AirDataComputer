## Status
[Work in progress, refer to the Wiki](https://github.com/BasicAirData/AirDataComputer/wiki)

## Introduction
Within "Hardware Integration Test" folder you find a sketch for test the hardware of a Asgard ADC.
Firmware folder will contain the sketch that need to ve uploaded to ADC. The firmware supports Bluetooth and SD card.
Libraries folder contains the libraries you need to place in your library Arduino IDE folder to be able to compile the ADC sketch.
